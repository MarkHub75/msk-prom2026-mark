---
id: object_filters
title: Filters
---

import ConfigTabs from "@site/src/components/ConfigTabs";
import TabItem from "@theme/TabItem";
import NavPath from "@site/src/components/NavPath";

There are several types of object filters that can be used to reduce [false positive](/frigate/glossary#false-positive) rates.

## Object Scores

For object filters, any single detection below `min_score` will be ignored as a false positive. `threshold` is based on the median of the history of scores (padded to 3 values) for a tracked object. Consider the following frames when `min_score` is set to 0.6 and threshold is set to 0.85:

| Frame | Current Score | Score History                     | Computed Score | Detected Object |
| ----- | ------------- | --------------------------------- | -------------- | --------------- |
| 1     | 0.7           | 0.0, 0, 0.7                       | 0.0            | No              |
| 2     | 0.55          | 0.0, 0.7, 0.0                     | 0.0            | No              |
| 3     | 0.85          | 0.7, 0.0, 0.85                    | 0.7            | No              |
| 4     | 0.90          | 0.7, 0.85, 0.95, 0.90             | 0.875          | Yes             |
| 5     | 0.88          | 0.7, 0.85, 0.95, 0.90, 0.88       | 0.88           | Yes             |
| 6     | 0.95          | 0.7, 0.85, 0.95, 0.90, 0.88, 0.95 | 0.89           | Yes             |

In frame 2, the score is below the `min_score` value, so Frigate ignores it and it becomes a 0.0. The computed score is the median of the score history (padding to at least 3 values), and only when that computed score crosses the `threshold` is the object marked as a true positive. That happens in frame 4 in the example.

The **top score** is the highest computed score the tracked object has ever reached during its lifetime. Because the computed score rises and falls as new frames come in, the top score can be thought of as the peak confidence Frigate had in the object. In Frigate's UI (such as the Tracking Details pane in Explore), you may see all three values:

- **Score**: the raw detector score for that single frame.
- **Computed Score**: the median of the most recent score history at that moment. This is the value compared against `threshold`.
- **Top Score**: the highest computed score reached so far for the tracked object.

### Minimum Score

Any detection below `min_score` will be immediately thrown out and never tracked because it is considered a false positive. If `min_score` is too low then false positives may be detected and tracked which can confuse the object tracker and may lead to wasted resources. If `min_score` is too high then lower scoring true positives like objects that are further away or partially occluded may be thrown out which can also confuse the tracker and cause valid tracked objects to be lost or disjointed.

### Threshold

`threshold` is used to determine that the object is a true positive. Once an object is detected with a score >= `threshold` object is considered a true positive. If `threshold` is too low then some higher scoring false positives may create a tracked object. If `threshold` is too high then true positive tracked objects may be missed due to the object never scoring high enough.

## Configuring Object Scores

<ConfigTabs>
<TabItem value="ui">

Navigate to <NavPath path="Settings > Global configuration > Objects" /> to set score filters globally.

| Field                                              | Description                                                      |
| -------------------------------------------------- | ---------------------------------------------------------------- |
| **Object filters > Person > Minimum confidence**   | Minimum score for a single detection to initiate tracking        |
| **Object filters > Person > Confidence threshold** | Minimum computed (median) score to be considered a true positive |

To override score filters for a specific camera, navigate to <NavPath path="Settings > Camera configuration > Objects" /> and select the camera.

</TabItem>
<TabItem value="yaml">

```yaml
objects:
  filters:
    person:
      min_score: 0.5
      threshold: 0.7
```

To override at the camera level:

```yaml
cameras:
  front_door:
    objects:
      filters:
        person:
          min_score: 0.5
          threshold: 0.7
```

</TabItem>
</ConfigTabs>

## Object Shape

False positives can also be reduced by filtering a detection based on its shape.

### Object Area

`min_area` and `max_area` filter on the area of an objects bounding box and can be used to reduce false positives that are outside the range of expected sizes. For example when a leaf is detected as a dog or when a large tree is detected as a person, these can be reduced by adding a `min_area` / `max_area` filter. These values can either be in pixels or as a percentage of the frame (for example, 0.12 represents 12% of the frame).

### Object Proportions

`min_ratio` and `max_ratio` values are compared against a given detected object's width/height ratio (in pixels). If the ratio is outside this range, the object will be ignored as a false positive. This allows objects that are proportionally too short-and-wide (higher ratio) or too tall-and-narrow (smaller ratio) to be ignored.

:::info

Conceptually, a ratio of 1 is a square, 0.5 is a "tall skinny" box, and 2 is a "wide flat" box. If `min_ratio` is 1.0, any object that is taller than it is wide will be ignored. Similarly, if `max_ratio` is 1.0, then any object that is wider than it is tall will be ignored.

:::

### Configuring Shape Filters

<ConfigTabs>
<TabItem value="ui">

Navigate to <NavPath path="Settings > Global configuration > Objects" /> to set shape filters globally.

| Field                                              | Description                                                              |
| -------------------------------------------------- | ------------------------------------------------------------------------ |
| **Object filters > Person > Minimum object area**  | Minimum bounding box area in pixels (or decimal for percentage of frame) |
| **Object filters > Person > Maximum object area**  | Maximum bounding box area in pixels (or decimal for percentage of frame) |
| **Object filters > Person > Minimum aspect ratio** | Minimum width/height ratio of the bounding box                           |
| **Object filters > Person > Maximum aspect ratio** | Maximum width/height ratio of the bounding box                           |

To override shape filters for a specific camera, navigate to <NavPath path="Settings > Camera configuration > Objects" /> and select the camera.

</TabItem>
<TabItem value="yaml">

```yaml
objects:
  filters:
    person:
      min_area: 5000
      max_area: 100000
      min_ratio: 0.5
      max_ratio: 2.0
```

To override at the camera level:

```yaml
cameras:
  front_door:
    objects:
      filters:
        person:
          min_area: 5000
          max_area: 100000
```

</TabItem>
</ConfigTabs>

## Other Tools

### Zones

[Required zones](/configuration/zones.md#restricting-alerts-and-detections-to-specific-zones) can be a great tool to reduce false positives that may be detected in the sky or other areas that are not of interest. The required zones will only create tracked objects for objects that enter the zone.

### Object Masks

[Object Filter Masks](/configuration/masks#object-filter-masks) are a last resort but can be useful when false positives are in the relatively same place but can not be filtered due to their size or shape. Object filter masks can be configured in <NavPath path="Settings > Camera configuration > Masks / Zones" />.
