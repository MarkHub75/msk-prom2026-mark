from pydantic import BaseModel, Field
from pydantic.json_schema import SkipJsonSchema

from frigate.record.export import (
    ChaptersEnum,
    PlaybackSourceEnum,
)


class ExportRecordingsBody(BaseModel):
    source: PlaybackSourceEnum = Field(
        default=PlaybackSourceEnum.recordings, title="Playback source"
    )
    name: str | None = Field(title="Friendly name", default=None, max_length=256)
    image_path: str | SkipJsonSchema[None] = None
    export_case_id: str | None = Field(
        default=None,
        title="Export case ID",
        max_length=30,
        description="ID of the export case to assign this export to",
    )
    chapters: ChaptersEnum | None = Field(
        default=None,
        title="Chapter mode",
        description=(
            "Optional chapter metadata to embed in the export. When omitted, "
            "the camera's configured export chapter mode is used."
        ),
    )


class ExportRecordingsCustomBody(BaseModel):
    source: PlaybackSourceEnum = Field(
        default=PlaybackSourceEnum.recordings, title="Playback source"
    )
    name: str = Field(title="Friendly name", default=None, max_length=256)
    image_path: str | SkipJsonSchema[None] = None
    export_case_id: str | None = Field(
        default=None,
        title="Export case ID",
        max_length=30,
        description="ID of the export case to assign this export to",
    )
    ffmpeg_input_args: str | None = Field(
        default=None,
        title="FFmpeg input arguments",
        description="Custom FFmpeg input arguments. If not provided, defaults to timelapse input args.",
    )
    ffmpeg_output_args: str | None = Field(
        default=None,
        title="FFmpeg output arguments",
        description="Custom FFmpeg output arguments. If not provided, defaults to timelapse output args.",
    )
    cpu_fallback: bool = Field(
        default=False,
        title="CPU Fallback",
        description="If true, retry export without hardware acceleration if the initial export fails.",
    )
