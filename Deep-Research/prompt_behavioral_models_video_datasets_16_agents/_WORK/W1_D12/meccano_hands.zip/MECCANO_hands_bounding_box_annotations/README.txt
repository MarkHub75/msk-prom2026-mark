This README is related to the following scientific paper:
    
F. Ragusa, A. Furnari, G. M. Farinella. MECCANO: A Multimodal Egocentric Dataset for Humans Behavior Understanding in the Industrial-like Domain. 2022.

More information is available at our web page: http://iplab.dmi.unict.it/MECCANO 



In the folder there are the bounding box annotations of the hands related to the MECCANO Dataset.
You will find 1 .csv file for each video belonging to the three subsets of the MECCANO (Training, Validation and Test).

Each instance of the .csv file is composed of 7 fields as explained in the VGG Image Annotator tool:

	- filename which is the name of the frame;
	- file_size which indicates the size of the current frame;
	- file_attribute which represents optional additional information about the file (this field is empty);
	- region_count which is the number of bounding boxes present in the image;
	- region_id which is the identifier of the current bounding box annotation;
	- region_shape_attributes which indicates the 2D coordinates of the bounding box;
	- region_attributes which which represents the class of the current bounding box (SX_hand or DX_hand).
