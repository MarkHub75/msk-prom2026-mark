
This README is related to the following scientific paper:

F. Ragusa, A. Furnari, G. M. Farinella. MECCANO: A Multimodal Egocentric Dataset for Humans Behavior Understanding in the Industrial-like Domain. 2022.

In the folder there are:

        - the active objects annotations related to the 20 object classes of the MECCANO Dataset.
          You will find 3 .json files (COCO data format) one for each subset of the MECCANO (Training, Validation and Test).
