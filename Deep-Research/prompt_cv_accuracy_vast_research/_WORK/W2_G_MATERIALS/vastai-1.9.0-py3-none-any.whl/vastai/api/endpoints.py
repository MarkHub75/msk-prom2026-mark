"""Endpoint and workergroup API functions for the Vast.ai SDK."""


def show_endpoints(client):
    """Display user's current endpoint groups.

    GET /endptjobs/

    Args:
        client: VastClient instance.

    Returns:
        list: Endpoint group results with sensitive fields removed.
    """
    json_blob = {"client_id": "me", "api_key": client.api_key}
    r = client.get("/endptjobs/", json_data=json_blob)
    r.raise_for_status()

    if r.status_code == 200:
        rj = r.json()
        if rj["success"]:
            rows = rj["results"]
            for row in rows:
                row.pop("api_key", None)
                row.pop("auto_delete_in_seconds", None)
                row.pop("auto_delete_due_24h", None)
            return rows
        else:
            return {"error": rj["msg"]}
    return r.json()


def create_endpoint(client, **kwargs):
    """Create a new endpoint group.

    POST /endptjobs/

    Args:
        client: VastClient instance.
        **kwargs: Endpoint configuration options:
            min_load (float): Minimum floor load in perf units/s. Default 0.0.
            min_cold_load (float): Minimum floor load allowing cold workers. Default 0.0.
            target_util (float): Target capacity utilization (max 1.0). Default 0.9.
            cold_mult (float): Cold capacity target as multiple of hot. Default 2.5.
            cold_workers (int): Min cold workers when no load. Default 5.
            max_workers (int): Max workers for the endpoint group. Default 20.
            endpoint_name (str): Deployment endpoint name.
            auto_instance (str): Autoscaler instance type. Default "prod".

    Returns:
        dict: API response data.
    """
    json_blob = {
        "client_id": "me",
        "min_load": kwargs.get("min_load", 0.0),
        "min_cold_load": kwargs.get("min_cold_load", 0.0),
        "target_util": kwargs.get("target_util", 0.9),
        "cold_mult": kwargs.get("cold_mult", 2.5),
        "cold_workers": kwargs.get("cold_workers", 5),
        "max_workers": kwargs.get("max_workers", 20),
        "endpoint_name": kwargs.get("endpoint_name"),
        "max_queue_time": kwargs.get("max_queue_time"),
        "target_queue_time": kwargs.get("target_queue_time"),
        "inactivity_timeout": kwargs.get("inactivity_timeout"),
        "autoscaler_instance": kwargs.get("auto_instance", "prod"),
    }

    r = client.post("/endptjobs/", json_data=json_blob)
    r.raise_for_status()
    return r.json()


def update_endpoint(client, id, **kwargs):
    """Update an existing endpoint group.

    PUT /endptjobs/{id}/

    Args:
        client: VastClient instance.
        id (int): ID of endpoint group to update.
        **kwargs: Endpoint configuration options.

    Returns:
        dict: API response data.
    """
    json_blob = {
        "client_id": "me",
        "endptjob_id": id,
        "min_load": kwargs.get("min_load"),
        "min_cold_load": kwargs.get("min_cold_load"),
        "target_util": kwargs.get("target_util"),
        "cold_mult": kwargs.get("cold_mult"),
        "cold_workers": kwargs.get("cold_workers"),
        "max_workers": kwargs.get("max_workers"),
        "endpoint_name": kwargs.get("endpoint_name"),
        "endpoint_state": kwargs.get("endpoint_state"),
        "max_queue_time": kwargs.get("max_queue_time"),
        "target_queue_time": kwargs.get("target_queue_time"),
        "inactivity_timeout": kwargs.get("inactivity_timeout"),
        "autoscaler_instance": kwargs.get("auto_instance", "prod"),
    }
    r = client.put(f"/endptjobs/{id}/", json_data=json_blob)
    r.raise_for_status()
    return r.json()


def delete_endpoint(client, id):
    """Delete an endpoint group.

    DELETE /endptjobs/{id}/

    Args:
        client: VastClient instance.
        id (int): ID of endpoint group to delete.

    Returns:
        dict: API response data.
    """
    json_blob = {"client_id": "me", "endptjob_id": id}
    r = client.delete(f"/endptjobs/{id}/", json_data=json_blob)
    r.raise_for_status()
    return r.json()


def _get_autoscaler_base_url(client):
    """Derive the autoscaler base URL (used for logs, worker status, and
    update_workers; the autoscaler service is separate from the console API).

    If the client is using the default console.vast.ai URL, the autoscaler
    is at run.vast.ai. Otherwise the user's custom URL is used.
    """
    from vastai.api.client import server_url_default
    if client.server_url == server_url_default:
        return "https://run.vast.ai"
    return client.server_url


def get_endpt_logs(client, id, level=1, tail=None):
    """Fetch logs for a specific serverless endpoint group.

    POST to <base>/get_endpoint_logs/

    Args:
        client: VastClient instance.
        id (int): ID of endpoint group to fetch logs from.
        level (int): Log detail level (0 to 3). Default 1.
            0: info0, 1: info1, 2: trace, 3: debug
        tail (int, optional): Number of tail lines.

    Returns:
        dict: Log data from the API response.
    """
    base = _get_autoscaler_base_url(client)
    url = base + "/get_endpoint_logs/"
    json_blob = {"id": id, "api_key": client.api_key}
    if tail is not None:
        json_blob["tail"] = tail

    headers = {}
    if client.api_key is not None:
        headers["Authorization"] = "Bearer " + client.api_key

    r = client._request('POST', url, headers, json_blob)
    r.raise_for_status()

    if r.status_code == 200:
        rj = r.json()
        return rj
    return {"error": r.text}


def show_workergroups(client):
    """Display user's current workergroups.

    GET /autojobs/

    Args:
        client: VastClient instance.

    Returns:
        list: Workergroup results.
    """
    json_blob = {"client_id": "me", "api_key": client.api_key}
    r = client.get("/autojobs/", json_data=json_blob)
    r.raise_for_status()

    if r.status_code == 200:
        rj = r.json()
        if rj["success"]:
            return rj["results"]
        else:
            return {"error": rj["msg"]}
    return r.json()


def create_workergroup(client, **kwargs):
    """Create a new autoscale/workergroup.

    POST /autojobs/

    Args:
        client: VastClient instance.
        **kwargs: Workergroup configuration options:
            template_hash (str): Template hash (required).
            template_id (int): Template ID (optional).
            search_params (str): Search param string for search offers.
            launch_args (str): Launch args string for create instance.
            endpoint_name (str): Deployment endpoint name.
            endpoint_id (int): Deployment endpoint ID.
            gpu_ram (float): Estimated GPU RAM requirement.
            no_default (bool): Disable default search param query args.
            auto_instance (str): Autoscaler instance type. Default "prod".

    Returns:
        dict: API response data.
    """
    no_default = kwargs.get("no_default", False)
    if no_default:
        query = ""
    else:
        query = " verified=True rentable=True rented=False"

    search_params_arg = kwargs.get("search_params")
    search_params = ((search_params_arg if search_params_arg is not None else "") + query).strip()

    json_blob = {
        "client_id": "me",
        "template_hash": kwargs.get("template_hash"),
        "template_id": kwargs.get("template_id"),
        "search_params": search_params,
        "launch_args": kwargs.get("launch_args"),
        "gpu_ram": kwargs.get("gpu_ram"),
        "endpoint_name": kwargs.get("endpoint_name"),
        "endpoint_id": kwargs.get("endpoint_id"),
        "autoscaler_instance": kwargs.get("auto_instance", "prod"),
    }

    r = client.post("/autojobs/", json_data=json_blob)
    r.raise_for_status()
    return r.json()


def update_workergroup(client, id, **kwargs):
    """Update an existing workergroup.

    PUT /autojobs/{id}/

    Args:
        client: VastClient instance.
        id (int): ID of workergroup to update.
        **kwargs: Workergroup configuration options.

    Returns:
        dict: API response data.
    """
    no_default = kwargs.get("no_default", False)
    if no_default:
        query = ""
    else:
        query = " verified=True rentable=True rented=False"

    search_params_arg = kwargs.get("search_params")
    search_params = ((search_params_arg if search_params_arg is not None else "") + query).strip()

    json_blob = {
        "client_id": "me",
        "autojob_id": id,
        "template_hash": kwargs.get("template_hash"),
        "template_id": kwargs.get("template_id"),
        "search_params": search_params,
        "launch_args": kwargs.get("launch_args"),
        "gpu_ram": kwargs.get("gpu_ram"),
        "endpoint_name": kwargs.get("endpoint_name"),
        "endpoint_id": kwargs.get("endpoint_id"),
    }
    r = client.put(f"/autojobs/{id}/", json_data=json_blob)
    r.raise_for_status()
    return r.json()


def delete_workergroup(client, id):
    """Delete a workergroup.

    DELETE /autojobs/{id}/

    Note: Deleting a workergroup does not automatically destroy all
    associated instances.

    Args:
        client: VastClient instance.
        id (int): ID of workergroup to delete.

    Returns:
        dict: API response data.
    """
    json_blob = {"client_id": "me", "autojob_id": id}
    r = client.delete(f"/autojobs/{id}/", json_data=json_blob)
    r.raise_for_status()
    return r.json()


def get_wrkgrp_logs(client, id, level=1, tail=None):
    """Fetch logs for a specific serverless worker group.

    POST to <base>/get_autogroup_logs/

    Args:
        client: VastClient instance.
        id (int): ID of worker group to fetch logs from.
        level (int): Log detail level (0 to 3). Default 1.
            0: info0, 1: info1, 2: trace, 3: debug
        tail (int, optional): Number of tail lines.

    Returns:
        dict: Log data from the API response.
    """
    base = _get_autoscaler_base_url(client)
    url = base + "/get_autogroup_logs/"
    json_blob = {"id": id, "api_key": client.api_key}
    if tail is not None:
        json_blob["tail"] = tail

    headers = {}
    if client.api_key is not None:
        headers["Authorization"] = "Bearer " + client.api_key

    r = client._request('POST', url, headers, json_blob)
    r.raise_for_status()

    if r.status_code == 200:
        rj = r.json()
        return rj
    return {"error": r.text}


def get_endpoint_workers(client, id):
    """List the live worker instances under a given endpoint, with runtime
    status (creating/loading/idle/error/...) and ``measured_perf``.

    Different from ``show_workergroups``: that one returns the user's
    workergroup config records (template, search params, scaling policy, etc).
    This returns the actual rented instances under one endpoint with their
    current status.

    POST to <base>/get_endpoint_workers/

    Args:
        client: VastClient instance.
        id (int): ID of endpoint whose workers to list.

    Returns:
        list | dict: Worker data from the API response.
    """
    base = _get_autoscaler_base_url(client)
    url = base + "/get_endpoint_workers/"
    json_blob = {"id": id}

    headers = {}
    if client.api_key is not None:
        headers["Authorization"] = "Bearer " + client.api_key

    r = client._request('POST', url, headers, json_blob)
    r.raise_for_status()
    return r.json()


def update_workers(client, id: int, cancel: bool = False):
    """Trigger a rolling update of all workers in a workergroup, or cancel an in-progress update.

    POST /update_workers/

    Args:
        client: VastClient instance.
        id: Workergroup ID.
        cancel: If True, cancel an in-progress update.

    Returns:
        dict: Result from the autoscaler.
    """
    from vastai.api.client import server_url_default
    base_url = client.server_url
    if base_url == server_url_default:
        base_url = "https://run.vast.ai"
    url = base_url + "/update_workers/"
    json_blob = {"workergroup_id": id, "api_key": client.api_key}
    if cancel:
        json_blob["cancel_update"] = True

    headers = {}
    if client.api_key is not None:
        headers["Authorization"] = "Bearer " + client.api_key

    r = client._request('POST', url, headers, json_blob)
    r.raise_for_status()
    return r.json()
