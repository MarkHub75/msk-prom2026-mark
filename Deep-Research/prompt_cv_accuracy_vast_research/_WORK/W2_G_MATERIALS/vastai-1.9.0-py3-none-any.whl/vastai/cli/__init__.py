"""Vast.ai CLI layer."""
