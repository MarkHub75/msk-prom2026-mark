"""CLI commands for managing volumes, storage, copies, and cloud sync."""

import json
import os
import time
import subprocess
from urllib.parse import quote, urlparse

from vastai.cli.parser import argument
from vastai.cli.display import (
    display_table, vol_displayable_fields, nw_vol_displayable_fields,
    volume_fields, connection_fields, deindent,
    instance_backup_fields, instance_backup_file_fields,
)
from vastai.cli.display import strip_strings
from vastai.cli.util import (
    default_start_date,
    parse_day_cron_style, parse_hour_cron_style,
    validate_frequency_values, add_scheduled_job,
)
from vastai.api import storage as storage_api
from vastai.api import offers as offers_api


from vastai.cli.utils import get_parser as _get_parser, get_client  # noqa: F401


parser = _get_parser()


# ---------------------------------------------------------------------------
# copy / cancel copy / cancel sync
# ---------------------------------------------------------------------------

@parser.command(
    argument("src", help="Source location for copy operation (supports multiple formats)", type=str),
    argument("dst", help="Target location for copy operation (supports multiple formats)", type=str),
    argument("-i", "--identity", help="Location of ssh private key", type=str),
    usage="vastai copy SRC DST",
    help="Copy directories between instances and/or local",
    epilog=deindent("""
        Copies a directory from a source location to a target location. Each of source and destination
        directories can be either local or remote, subject to appropriate read and write
        permissions required to carry out the action.

        Supported location formats:
        - [instance_id:]path               (legacy format, still supported)
        - C.instance_id:path              (container copy format)
        - cloud_service:path              (cloud service format)
        - cloud_service.cloud_service_id:path  (cloud service with ID)
        - local:path                      (explicit local path)
        - V.volume_id:path                (volume copy)

        You should not copy to /root or / as a destination directory, as this can mess up the permissions on your instance ssh folder, breaking future copy operations (as they use ssh authentication)
        You can see more information about constraints here: https://vast.ai/docs/gpu-instances/data-movement#constraints
        Volume copy is currently only supported for copying to other volumes, instances, or cloud services, not local.

        Examples:
         vastai copy 6003036:/workspace/ 6003038:/workspace/
         vastai copy C.11824:/data/test local:data/test
         vastai copy local:data/test C.11824:/data/test
         vastai copy drive:/folder/file.txt C.6003036:/workspace/
         vastai copy s3.101:/data/ C.6003036:/workspace/
         vastai copy hf.101:/my-bucket/data/ C.6003036:/workspace/
         vastai copy V.1234:/file C.5678:/workspace/
         vastai copy V.1234:/file s3.101:/workspace/

        The first example copy syncs all files from the absolute directory '/workspace' on instance 6003036 to the directory '/workspace' on instance 6003038.
        The second example copy syncs files from container 11824 to the local machine using structured syntax.
        The third example copy syncs files from local to container 11824 using structured syntax.
        The fourth example copy syncs files from Google Drive to an instance.
        The fifth example copy syncs files from S3 bucket with id 101 to an instance.
        The sixth example copy syncs files from a Hugging Face bucket using connection id 101 to an instance.
        The seventh example copy syncs files from volume 1234 to instance 5678.
        The eighth example copy syncs files from volume 1234 to S3 bucket with id 101.
    """),
)
def copy(args):
    """Transfer data from one instance to another."""
    from vastai.utils import parse_vast_url
    client = get_client(args)

    (src_id, src_path) = parse_vast_url(args.src)
    (dst_id, dst_path) = parse_vast_url(args.dst)

    print(f"copying {str(src_id)+':' if src_id else ''}{src_path} {str(dst_id)+':' if dst_id else ''}{dst_path}")

    if args.explain:
        print("request json: ")
        print({"client_id": "me", "src_id": src_id, "dst_id": dst_id, "src_path": src_path, "dst_path": dst_path})

    rj = storage_api.copy(client, src_id=src_id, dst_id=dst_id, src_path=src_path, dst_path=dst_path)

    if (rj.get("success")) and ((src_id is None or src_id == "local") or (dst_id is None or dst_id == "local")):
        ssh_args = ["ssh"]
        if args.identity is not None:
            ssh_args.extend(["-i", args.identity])
        if (src_id is None or src_id == "local"):
            remote_port = rj["dst_port"]
            remote_addr = rj["dst_addr"]
            ssh_cmd = " ".join(ssh_args + ["-p", str(remote_port), "-o", "StrictHostKeyChecking=no"])
            cmd = [
                "rsync", "-arz", "-v", "--progress", "--rsh=ssh", "-e", ssh_cmd,
                src_path, f"vastai_kaalia@{remote_addr}::{dst_id}/{dst_path}",
            ]
            print(" ".join(cmd))
            subprocess.run(cmd)
        elif (dst_id is None or dst_id == "local"):
            os.makedirs(dst_path, exist_ok=True)
            remote_port = rj["src_port"]
            remote_addr = rj["src_addr"]
            ssh_cmd = " ".join(ssh_args + ["-p", str(remote_port), "-o", "StrictHostKeyChecking=no"])
            cmd = [
                "rsync", "-arz", "-v", "--progress", "--rsh=ssh", "-e", ssh_cmd,
                f"vastai_kaalia@{remote_addr}::{src_id}/{src_path}", dst_path,
            ]
            print(" ".join(cmd))
            subprocess.run(cmd)
    else:
        if rj.get("success"):
            print("Remote to Remote copy initiated - check instance status bar for progress updates (~30 seconds delayed).")
        else:
            if rj.get("msg") == "src_path not supported VMs.":
                print("copy between VM instances does not currently support subpaths (only full disk copy)")
            elif rj.get("msg") == "dst_path not supported for VMs.":
                print("copy between VM instances does not currently support subpaths (only full disk copy)")
            else:
                print(rj.get("msg", rj))


@parser.command(
    argument("dst", help="instance_id:/path to target of copy operation", type=str),
    usage="vastai cancel copy DST",
    help="Cancel a remote copy in progress, specified by DST id",
    epilog=deindent("""
        Use this command to cancel any/all current remote copy operations copying to a specific named instance, given by DST.

        Examples:
         vastai cancel copy 12371

        The first example cancels all copy operations currently copying data into instance 12371

    """),
)
def cancel__copy(args):
    """Cancel a remote copy in progress, specified by DST id."""
    client = get_client(args)
    dst_id = args.dst
    if dst_id is None:
        print("invalid arguments")
        return

    print(f"canceling remote copies to {dst_id} ")

    rj = storage_api.cancel_copy(client, dst_id=dst_id)
    if rj.get("success"):
        print("Remote copy canceled - check instance status bar for progress updates (~30 seconds delayed).")
    else:
        print(rj.get("msg", rj))


@parser.command(
    argument("dst", help="instance_id:/path to target of sync operation", type=str),
    usage="vastai cancel sync DST",
    help="Cancel a remote copy in progress, specified by DST id",
    epilog=deindent("""
        Use this command to cancel any/all current remote cloud sync operations copying to a specific named instance, given by DST.

        Examples:
         vastai cancel sync 12371

        The first example cancels all copy operations currently copying data into instance 12371

    """),
)
def cancel__sync(args):
    """Cancel a remote cloud sync in progress, specified by DST id."""
    client = get_client(args)
    dst_id = args.dst
    if dst_id is None:
        print("invalid arguments")
        return

    print(f"canceling remote copies to {dst_id} ")

    rj = storage_api.cancel_sync(client, dst_id=dst_id)
    if rj.get("success"):
        print("Remote copy canceled - check instance status bar for progress updates (~30 seconds delayed).")
    else:
        print(rj.get("msg", rj))


# ---------------------------------------------------------------------------
# cloud copy
# ---------------------------------------------------------------------------

@parser.command(
    argument("--src", help="path to source of object to copy", type=str),
    argument("--dst", help="path to target of copy operation", type=str, default="/workspace"),
    argument("--instance", help="id of the instance", type=str),
    argument("--connection", help="id of cloud connection on your account (get from calling 'vastai show connections')", type=str),
    argument("--transfer", help="type of transfer, possible options include Instance To Cloud and Cloud To Instance", type=str, default="Instance to Cloud"),
    argument("--dry-run", help="show what would have been transferred", action="store_true"),
    argument("--size-only", help="skip based on size only, not mod-time or checksum", action="store_true"),
    argument("--ignore-existing", help="skip all files that exist on destination", action="store_true"),
    argument("--update", help="skip files that are newer on the destination", action="store_true"),
    argument("--delete-excluded", help="delete files on dest excluded from transfer", action="store_true"),
    argument("--schedule", choices=["HOURLY", "DAILY", "WEEKLY"], help="try to schedule a command to run hourly, daily, or weekly. Valid values are HOURLY, DAILY, WEEKLY  For ex. --schedule DAILY"),
    argument("--start_date", type=str, default=default_start_date(), help="Start date/time in format 'YYYY-MM-DD HH:MM:SS PM' (UTC). Default is now. (optional)"),
    argument("--end_date", type=str, help="End date/time in format 'YYYY-MM-DD HH:MM:SS PM' (UTC). Default is contract's end. (optional)"),
    argument("--day", type=parse_day_cron_style, help="Day of week you want scheduled job to run on (0-6, where 0=Sunday) or \"*\". Default will be 0. For ex. --day 0", default=0),
    argument("--hour", type=parse_hour_cron_style, help="Hour of day you want scheduled job to run on (0-23) or \"*\" (UTC). Default will be 0. For ex. --hour 16", default=0),
    usage="vastai cloud copy --src SRC --dst DST --instance INSTANCE_ID --connection CONNECTION_ID --transfer TRANSFER_TYPE",
    help="Copy files/folders to and from cloud providers",
    epilog=deindent("""
        Copies a directory from a source location to a target location. Each of source and destination
        directories can be either local or remote, subject to appropriate read and write
        permissions required to carry out the action. The format for both src and dst is [instance_id:]path.
        You can find more information about the cloud copy operation here: https://vast.ai/docs/gpu-instances/cloud-sync

        Examples:
         vastai show connections
         ID    NAME      Cloud Type
         1001  test_dir  drive
         1003  data_dir  drive
         1004  hf_data   hf

         vastai cloud copy --src /folder --dst /workspace --instance 6003036 --connection 1001 --transfer "Instance To Cloud"
         vastai cloud copy --src my-bucket/data --dst /workspace --instance 6003036 --connection 1004 --transfer "Cloud To Instance"

        The first cloud copy example copies all contents of /folder on instance 6003036 into /workspace in gdrive connection 'test_dir'.
        The second cloud copy example copies my-bucket/data from Hugging Face connection 'hf_data' into /workspace on the instance.

        Note: Hugging Face cloud destinations must already exist as bucket paths; directories are not created automatically.
    """),
)
def cloud__copy(args):
    """Transfer data to/from cloud providers."""
    client = get_client(args)

    if (args.src is None) and (args.dst is None):
        print("invalid arguments")
        return

    flags = storage_api.rclone_flags(
        dry_run=args.dry_run, size_only=args.size_only,
        ignore_existing=args.ignore_existing, update=args.update,
        delete_excluded=args.delete_excluded,
    )

    print(f"copying {args.src} {args.dst} {args.instance} {args.connection} {args.transfer}")

    req_json = {
        "src": args.src,
        "dst": args.dst,
        "instance_id": args.instance,
        "selected": args.connection,
        "transfer": args.transfer,
        "flags": flags
    }

    if args.explain:
        print("request json: ")
        print(req_json)

    if args.schedule:
        validate_frequency_values(args.day, args.hour, args.schedule)
        r = client.get(f"/instances/{args.instance}/", query_args={"owner": "me"})
        r.raise_for_status()
        row = r.json()["instances"]

        if args.transfer.lower() == "instance to cloud":
            if row:
                up_cost = row.get("internet_up_cost_per_tb", None)
                if up_cost is not None:
                    confirm = input(
                        f"Internet upload cost is ${up_cost} per TB. "
                        "Are you sure you want to schedule a cloud backup? (y/n): "
                    ).strip().lower()
                    if confirm != "y":
                        print("Cloud backup scheduling aborted.")
                        return
                else:
                    print("Warning: Could not retrieve internet upload cost. Proceeding without confirmation. You can use show scheduled-jobs and delete scheduled-job commands to delete scheduled cloud backup job.")

                cli_command = "cloud copy"
                api_endpoint = "/api/v0/commands/rclone/"
                contract_end_date = row.get("end_date", None)
                add_scheduled_job(client, args, req_json, cli_command, api_endpoint, "POST", instance_id=args.instance, contract_end_date=contract_end_date)
                return
            else:
                print("Instance not found. Please check the instance ID.")
                return

    rj = storage_api.cloud_copy(client, src=args.src, dst=args.dst, instance=args.instance,
                                connection=args.connection, transfer=args.transfer, flags=flags)
    if rj:
        print("Cloud Copy Started - check instance status bar for progress updates (~30 seconds delayed).")
        print("When the operation is finished you should see 'Cloud Copy Operation Finished' in the instance status bar.")


# ---------------------------------------------------------------------------
# show connections
# ---------------------------------------------------------------------------

@parser.command(
    usage="vastai show connections [--api-key API_KEY] [--raw]",
    help="Display user's cloud connections",
)
def show__connections(args):
    """Show the user's cloud connections."""
    client = get_client(args)
    rows = storage_api.show_connections(client)

    if args.raw:
        return rows
    else:
        display_table(rows, connection_fields)


# ---------------------------------------------------------------------------
# Note: show__network_disks and add__network_disk are in machines.py.
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# search volumes
# ---------------------------------------------------------------------------

@parser.command(
    argument("-n", "--no-default", action="store_true", help="Disable default query"),
    argument("--limit", type=int, help=""),
    argument("--storage", type=float, default=1.0, help="Amount of storage to use for pricing, in GiB. default=1.0GiB"),
    argument("-o", "--order", type=str, help="Comma-separated list of fields to sort on. postfix field with - to sort desc. ex: -o 'disk_space,inet_up-'.  default='score-'", default='score-'),
    argument("query", help="Query to search for. default: 'external=false verified=true disk_space>=1', pass -n to ignore default", nargs="*", default=None),
    usage="vastai search volumes [--help] [--api-key API_KEY] [--raw] <query>",
    help="Search for volume offers using custom query",
    epilog=deindent("""
        Query syntax:

            query = comparison comparison...
            comparison = field op value
            field = <name of a field>
            op = one of: <, <=, ==, !=, >=, >, in, notin
            value = <bool, int, float, string> | 'any' | [value0, value1, ...]
            bool: True, False

        note: to pass '>' and '<' on the command line, make sure to use quotes
        note: to encode a string query value (ie for gpu_name), replace any spaces ' ' with underscore '_'

        Examples:

            # search for volumes with greater than 50GB of available storage and greater than 500 Mb/s upload and download speed
            vastai search volumes "disk_space>50 inet_up>500 inet_down>500"

        Available fields:

              Name                  Type       Description

            cpu_arch:               string    host machine cpu architecture (e.g. amd64, arm64)
            cuda_vers:              float     machine max supported cuda version (based on driver version)
            datacenter:             bool      show only datacenter offers
            disk_bw:                float     disk read bandwidth, in MB/s
            disk_space:             float     disk storage space, in GB
            driver_version:         string    machine's nvidia/amd driver version as 3 digit string ex. "535.86.05"
            duration:               float     max rental duration in days
            geolocation:            string    Two letter country code. Works with operators =, !=, in, notin (e.g. geolocation not in ['XV','XZ'])
            gpu_arch:               string    host machine gpu architecture (e.g. nvidia, amd)
            gpu_name:               string    GPU model name (no quotes, replace spaces with underscores, ie: RTX_3090 rather than 'RTX 3090')
            has_avx:                bool      CPU supports AVX instruction set.
            id:                     int       volume offer unique ID
            inet_down:              float     internet download speed in Mb/s
            inet_up:                float     internet upload speed in Mb/s
            machine_id:             int       machine id of volume offer
            pci_gen:                float     PCIE generation
            pcie_bw:                float     PCIE bandwidth (CPU to GPU)
            reliability:            float     machine reliability score (see FAQ for explanation)
            storage_cost:           float     storage cost in $/GB/month
            static_ip:              bool      is the IP addr static/stable
            total_flops:            float     total TFLOPs from all GPUs
            ubuntu_version:         string    host machine ubuntu OS version
            verified:               bool      is the machine verified
    """),
)
def search__volumes(args):
    """Search for volume offers using custom query."""
    from vastai.api.query import parse_query, vol_offers_fields, offers_alias, offers_mult

    try:
        if args.no_default:
            query = {}
        else:
            query = {"verified": {"eq": True}, "external": {"eq": False}, "disk_space": {"gte": 1}}

        if args.query is not None:
            query = parse_query(args.query, query, vol_offers_fields, {}, offers_mult)

        order = []
        for name in args.order.split(","):
            name = name.strip()
            if not name:
                continue
            direction = "asc"
            field = name
            if name.strip("-") != name:
                direction = "desc"
                field = name.strip("-")
            if name.strip("+") != name:
                direction = "asc"
                field = name.strip("+")
            if field in offers_alias:
                field = offers_alias[field]
            order.append([field, direction])
    except ValueError as e:
        print("Error: ", e)
        return 1

    client = get_client(args)

    if args.explain:
        print("request json: ")
        print(query)

    rows = offers_api.search_volumes(
        client, query=query, order=order,
        limit=args.limit, storage=args.storage,
        no_default=True,  # defaults already applied above
    )

    if args.raw:
        return rows
    else:
        display_table(rows, vol_displayable_fields)


# ---------------------------------------------------------------------------
# search network volumes
# ---------------------------------------------------------------------------

@parser.command(
    argument("-n", "--no-default", action="store_true", help="Disable default query"),
    argument("--limit", type=int, help=""),
    argument("--storage", type=float, default=1.0, help="Amount of storage to use for pricing, in GiB. default=1.0GiB"),
    argument("-o", "--order", type=str, help="Comma-separated list of fields to sort on. postfix field with - to sort desc. ex: -o 'disk_space,inet_up-'.  default='score-'", default='score-'),
    argument("query", help="Query to search for. default: 'external=false verified=true disk_space>=1', pass -n to ignore default", nargs="*", default=None),
    usage="vastai search network volumes [--help] [--api-key API_KEY] [--raw] <query>",
    help="Search for network volume offers using custom query",
    epilog=deindent("""
        Query syntax:

            query = comparison comparison...
            comparison = field op value
            field = <name of a field>
            op = one of: <, <=, ==, !=, >=, >, in, notin
            value = <bool, int, float, string> | 'any' | [value0, value1, ...]
            bool: True, False

        note: to pass '>' and '<' on the command line, make sure to use quotes
        note: to encode a string query value (ie for gpu_name), replace any spaces ' ' with underscore '_'

        Examples:

            # search for volumes with greater than 50GB of available storage and greater than 500 Mb/s upload and download speed
            vastai search volumes "disk_space>50 inet_up>500 inet_down>500"

        Available fields:

              Name                  Type       Description
            duration:               float     max rental duration in days
            geolocation:            string    Two letter country code. Works with operators =, !=, in, notin (e.g. geolocation not in ['XV','XZ'])
            id:                     int       volume offer unique ID
            inet_down:              float     internet download speed in Mb/s
            inet_up:                float     internet upload speed in Mb/s
            reliability:            float     machine reliability score (see FAQ for explanation)
            storage_cost:           float     storage cost in $/GB/month
            verified:               bool      is the machine verified
    """),
)
def search__network_volumes(args):
    """Search for network volume offers using custom query."""
    from vastai.api.query import parse_query, vol_offers_fields, offers_alias, offers_mult

    try:
        if args.no_default:
            query = {}
        else:
            query = {"verified": {"eq": True}, "external": {"eq": False}, "disk_space": {"gte": 1}}

        if args.query is not None:
            query = parse_query(args.query, query, vol_offers_fields, {}, offers_mult)

        order = []
        for name in args.order.split(","):
            name = name.strip()
            if not name:
                continue
            direction = "asc"
            field = name
            if name.strip("-") != name:
                direction = "desc"
                field = name.strip("-")
            if name.strip("+") != name:
                direction = "asc"
                field = name.strip("+")
            if field in offers_alias:
                field = offers_alias[field]
            order.append([field, direction])
    except ValueError as e:
        print("Error: ", e)
        return 1

    client = get_client(args)

    if args.explain:
        print("request json: ")
        print(query)

    rows = offers_api.search_network_volumes(
        client, query=query, order=order,
        limit=args.limit, storage=args.storage,
        no_default=True,  # defaults already applied above
    )

    if args.raw:
        return rows
    else:
        display_table(rows, nw_vol_displayable_fields)


# ---------------------------------------------------------------------------
# create / delete / clone volume
# ---------------------------------------------------------------------------

@parser.command(
    argument("id", help="id of volume offer", type=int),
    argument("-s", "--size",
             help="size in GB of volume. Default %(default)s GB.", default=15, type=float),
    argument("-n", "--name", help="Optional name of volume.", type=str),
    usage="vastai create volume ID [options]",
    help="Create a new volume",
    epilog=deindent("""
        Creates a volume from an offer ID (which is returned from "search volumes"). Each offer ID can be used to create multiple volumes,
        provided the size of all volumes does not exceed the size of the offer.
    """),
)
def create__volume(args):
    """Create a new volume from an offer ID."""
    if args.explain:
        print("request json: ")
        print({"size": int(args.size), "id": int(args.id)})

    client = get_client(args)
    result = storage_api.create_volume(client, id=args.id, size=args.size, name=args.name)
    if args.raw:
        return result
    else:
        print("Created. {}".format(result))


@parser.command(
    argument("id", help="id of network volume offer", type=int),
    argument("-s", "--size",
             help="size in GB of network volume. Default %(default)s GB.", default=15, type=float),
    argument("-n", "--name", help="Optional name of network volume.", type=str),
    usage="vastai create network volume ID [options]",
    help="Create a new network volume",
    epilog=deindent("""
        Creates a network volume from an offer ID (which is returned from "search network volumes"). Each offer ID can be used to create multiple volumes,
        provided the size of all volumes does not exceed the size of the offer.
    """),
)
def create__network_volume(args):
    """Create a new network volume from an offer ID."""
    if args.explain:
        print("request json: ")
        print({"size": int(args.size), "id": int(args.id)})

    client = get_client(args)
    result = storage_api.create_network_volume(client, id=args.id, size=args.size, name=args.name)
    if args.raw:
        return result
    else:
        print("Created. {}".format(result))


@parser.command(
    argument("id", help="id of volume contract", type=int),
    usage="vastai delete volume ID",
    help="Delete a volume",
    epilog=deindent("""
        Deletes volume with the given ID. All instances using the volume must be destroyed before the volume can be deleted.
    """),
)
def delete__volume(args):
    """Delete a volume."""
    client = get_client(args)
    result = storage_api.delete_volume(client, id=args.id)
    if args.raw:
        return result
    else:
        print("Deleted. {}".format(result))


@parser.command(
    argument("source", help="id of volume contract being cloned", type=int),
    argument("dest", help="id of volume offer volume is being copied to", type=int),
    argument("-s", "--size", help="Size of new volume contract, in GB. Must be greater than or equal to the source volume, and less than or equal to the destination offer.", type=float),
    argument("-d", "--disable_compression", action="store_true", help="Do not compress volume data before copying."),
    usage="vastai clone volume <source_id> <dest_id> [options]",
    help="Clone an existing volume",
    epilog=deindent("""
        Create a new volume with the given offer, by copying the existing volume.
        Size defaults to the size of the existing volume, but can be increased if there is available space.
    """),
)
def clone__volume(args):
    """Clone an existing volume."""
    if args.explain:
        print("request json: ")
        print({"src_id": args.source, "dst_id": args.dest})

    client = get_client(args)
    result = storage_api.clone_volume(client, source=args.source, dest=args.dest,
                                      size=args.size, disable_compression=args.disable_compression)
    if args.raw:
        return result
    else:
        print("Created. {}".format(result))


# ---------------------------------------------------------------------------
# show volumes
# ---------------------------------------------------------------------------

@parser.command(
    argument("-t", "--type", help="volume type to display. Default to all. Possible values are \"local\", \"all\", \"network\"", type=str, default="all"),
    usage="vastai show volumes [OPTIONS]",
    help="Show stats on owned volumes.",
    epilog=deindent("""
        Show stats on owned volumes
    """),
)
def show__volumes(args):
    """Show stats on owned volumes."""
    client = get_client(args)
    processed = storage_api.show_volumes(client, type=args.type)
    for row in processed:
        for k, v in row.items():
            row[k] = strip_strings(v)
    if args.raw:
        return processed
    else:
        display_table(processed, volume_fields, replace_spaces=False)


# ---------------------------------------------------------------------------
# show instance-backups / show instance-backup-files
# ---------------------------------------------------------------------------

def _authorized_url(url, token):
    """Fold the download token into `url` as a query parameter.

    B2 takes the token either in the Authorization header or as an `Authorization`
    query parameter, and the second form is what makes a URL usable on its own -- paste
    it into a browser, or curl it without -H. Returns the url untouched when either
    piece is missing, so a malformed payload still lists its files.
    """
    if not url or not token:
        return url
    sep = "&" if urlparse(url).query else "?"
    return "{}{}Authorization={}".format(url, sep, quote(token, safe=""))


@parser.command(
    argument("--contract-id", help="only show backups of this instance or volume contract id", type=int),
    usage="vastai show instance-backups [OPTIONS]",
    help="Show backups Vast has taken of your instances.",
    epilog=deindent("""
        Lists the backups Vast has taken of your instances and volumes, newest first. These
        are created by Vast (for example before a machine is decommissioned), not by you.

        Status is pending while the copy runs, then success or error. A backup outlives the
        instance it came from, so entries stay listed after the instance is gone.

        Restore one into a running instance with `vastai copy`, naming vast.CONTRACT_ID as
        the source. An instance's own filesystem sits under upper/:

            vastai show instance-backups
            vastai copy vast.12345678:/upper/workspace 99887766:/workspace

        A backed-up volume has no upper/ -- its contents sit at the root of its own
        contract id:

            vastai copy vast.12345679:/ 99887766:/volumes/data

        To pull the objects down directly instead of restoring into an instance, see
        `vastai show instance-backup-files CONTRACT_ID`.

        Example: vastai show instance-backups --contract-id 12345678
    """),
)
def show__instance_backups(args):
    """Show backups Vast has taken of your instances."""
    client = get_client(args)
    rows = storage_api.show_instance_backups(client, contract_id=args.contract_id)
    if args.raw:
        return rows
    now = time.time()
    for row in rows:
        row["age_hours"] = (now - (row.get("created_at") or now)) / 3600.0
        # A backup whose contract has been archived out of the live tables reports no type.
        row["type"] = row.get("type") or "unknown"
        row["info"] = strip_strings(row.get("info") or "")
    display_table(rows, instance_backup_fields, replace_spaces=False)


@parser.command(
    argument("contract_id", help="instance or volume contract id whose backup to list", type=int),
    usage="vastai show instance-backup-files CONTRACT_ID [OPTIONS]",
    help="List the stored objects of one backup, with direct download URLs.",
    epilog=deindent("""
        Lists the objects stored for one backup. Each URL already carries a download token
        scoped to this backup, so it works on its own -- open it in a browser, or:

            curl -o model.safetensors "<url>"

        The token is also printed on its own for the header form, `curl -H "Authorization:
        <token>"`, which keeps it out of shell history and proxy logs. Either way it expires
        (the lifetime is printed), so re-run this command rather than saving the URLs.

        If the listing reports itself truncated, the backup holds more objects than are
        shown; restore with `vastai copy vast.CONTRACT_ID:/ INSTANCE_ID:/path` instead of
        fetching file by file.

        Example: vastai show instance-backup-files 12345678
    """),
)
def show__instance_backup_files(args):
    """List the stored objects of one backup, with direct download URLs."""
    client = get_client(args)
    blob = storage_api.instance_backup_files(client, args.contract_id)
    if args.raw:
        return blob
    files = blob.get("files") or []
    # --raw stays a passthrough of the API payload; only the table gets ready-to-click URLs.
    token = blob.get("authorization_token")
    for row in files:
        row["size_mb"] = (row.get("size") or 0) / 1e6
        row["url"] = _authorized_url(row.get("url"), token)
    print("authorization token: {} (already embedded in the URLs below)".format(token))
    print("expires in: {} seconds".format(blob.get("expires_in_sec")))
    if blob.get("truncated"):
        print("WARNING: listing truncated -- this backup holds more objects than shown below.")
    if not files:
        print("No objects stored for this backup yet.")
        return
    display_table(files, instance_backup_file_fields, replace_spaces=False)


# ---------------------------------------------------------------------------
# list / unlist volumes (host)
# ---------------------------------------------------------------------------

@parser.command(
    argument("id", help="id of machine to list", type=int),
    argument("-p", "--price_disk",
             help="storage price in $/GB/month, default: $%(default).2f/GB/month", default=.10, type=float),
    argument("-e", "--end_date", help="contract offer expiration - the available until date (optional, in unix float timestamp or MM/DD/YYYY format), default 3 months", type=str),
    argument("-s", "--size", help="size of disk space allocated to offer in GB, default %(default)s GB", default=15),
    usage="vastai list volume ID [options]",
    help="[Host] list disk space for rent as a volume on a machine",
    epilog=deindent("""
        Allocates a section of disk on a machine to be used for volumes.
    """),
)
def list__volume(args):
    """List disk space for rent as a volume on a machine."""
    from vastai.cli.util import string_to_unix_epoch

    end_date = string_to_unix_epoch(args.end_date) if args.end_date else None

    if args.explain:
        print("request json: ")
        print({"size": int(args.size), "machine": int(args.id), "price_disk": float(args.price_disk)})

    client = get_client(args)
    result = storage_api.list_volume(client, id=args.id, size=int(args.size),
                                     price_disk=float(args.price_disk), end_date=end_date)
    if args.raw:
        return result
    else:
        print("Created. {}".format(result))


@parser.command(
    argument("ids", help="id of machines list", type=int, nargs='+'),
    argument("-p", "--price_disk",
             help="storage price in $/GB/month, default: $%(default).2f/GB/month", default=.10, type=float),
    argument("-e", "--end_date", help="contract offer expiration - the available until date (optional, in unix float timestamp or MM/DD/YYYY format), default 3 months", type=str),
    argument("-s", "--size", help="size of disk space allocated to offer in GB, default %(default)s GB", default=15),
    usage="vastai list volume IDs [options]",
    help="[Host] list disk space for rent as a volume on machines",
    epilog=deindent("""
        Allocates a section of disk on machines to be used for volumes.
    """),
)
def list__volumes(args):
    """List disk space for rent as a volume on multiple machines."""
    from vastai.cli.util import string_to_unix_epoch

    end_date = string_to_unix_epoch(args.end_date) if args.end_date else None

    if args.explain:
        print("request json: ")
        print({"size": int(args.size), "machine": [int(id) for id in args.ids], "price_disk": float(args.price_disk)})

    client = get_client(args)
    result = storage_api.list_volumes(client, ids=args.ids, size=int(args.size),
                                      price_disk=float(args.price_disk), end_date=end_date)
    if args.raw:
        return result
    else:
        print("Created. {}".format(result))


@parser.command(
    argument("disk_id", help="id of network disk to list", type=int),
    argument("-p", "--price_disk", help="storage price in $/GB/month, default: $%(default).2f/GB/month", default=.15, type=float),
    argument("-e", "--end_date", help="contract offer expiration - the available until date (optional, in unix float timestamp or MM/DD/YYYY format), default 1 month", type=str, default=None),
    argument("-s", "--size", help="size of disk space allocated to offer in GB, default %(default)s GB", default=15, type=int),
    usage="vastai list network volume DISK_ID [options]",
    help="[Host] list disk space for rent as a network volume",
)
def list__network_volume(args):
    """List disk space for rent as a network volume."""
    from vastai.cli.util import string_to_unix_epoch

    end_date = string_to_unix_epoch(args.end_date) if args.end_date else None

    if args.explain:
        print("request json: ")
        print({"disk_id": args.disk_id, "price_disk": args.price_disk, "size": args.size})

    client = get_client(args)
    result = storage_api.list_network_volume(client, disk_id=args.disk_id, price_disk=args.price_disk,
                                             size=args.size, end_date=end_date)
    if args.raw:
        return result
    print(result["msg"])


@parser.command(
    argument("id", help="volume ID you want to unlist", type=int),
    usage="vastai unlist volume ID",
    help="[Host] unlist volume offer",
)
def unlist__volume(args):
    """Unlist a volume offer."""
    if args.explain:
        print("request json:", {"id": args.id})

    client = get_client(args)
    result = storage_api.unlist_volume(client, id=args.id)
    if args.raw:
        return result
    else:
        print(result["msg"])


@parser.command(
    argument("id", help="id of network volume offer to unlist", type=int),
    usage="vastai unlist network volume OFFER_ID",
    help="[Host] Unlists network volume offer",
)
def unlist__network_volume(args):
    """Unlist a network volume offer."""
    if args.explain:
        print("request json: ")
        print({"id": args.id})

    client = get_client(args)
    result = storage_api.unlist_network_volume(client, id=args.id)
    if args.raw:
        return result
    print(result["msg"])
